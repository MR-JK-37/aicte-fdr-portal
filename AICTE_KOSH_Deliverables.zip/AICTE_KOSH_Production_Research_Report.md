# AICTE KOSH — Production-Readiness Research & Implementation Blueprint

**Project:** SIH 2026 Problem Statement 26265 — Streamline of Security Deposit / FDR Portal  
**Research date:** 26 October 2026  
**Purpose:** Product requirements, roles, workflows, database/backend architecture, AI integration strategy and implementation phases for an existing web + mobile prototype that currently uses mock data and is not connected to a database.

> **Important scope boundary:** This is a technical/product research report, not an official AICTE approval, a legal opinion, or evidence that any bank/AICTE integration has been provisioned. The referenced AICTE FDR Production Specification v3.0 (research cut-off 23 October 2026) is treated as the domain baseline. Current AICTE policy, delegated authority, hosting, identity and external integrations must be signed off by their authorised owners before production use.

## 1. Executive recommendations

1. **Audit the existing project first.** Do not rewrite the frontend or replace its stack before documenting its current routes, UI, data stores, mock service layers, mobile technology, auth, build commands and deployment assumptions.
2. **Use one authoritative backend and one authoritative relational database.** Web and mobile are clients to the same domain APIs, database and workflow state machines; neither client should have its own source of truth.
3. **Prefer PostgreSQL** for the core system because institutions, programmes, deposits, evidence, observations, clearances, approvals, policies and audit events are connected entities with transactional constraints and role-scoped queries.
4. **Use a modular monolith for the first production-minded implementation.** Keep one deployable backend with explicit domain modules; add workers for OCR, notifications, document processing and scheduled maturity events. Do not start with microservices or a multi-agent runtime unless measured needs justify them.
5. **Connect real persistence before expanding AI.** Replace hardcoded arrays/local-only state with migrations, repositories/services, API contracts, persistent records and end-to-end tests. Keep generated fixtures in development/test only.
6. **Use RBAC + ABAC, not role-name checks alone.** An institution user is restricted to their institution; internal staff are restricted by authorised region, assignment, source/account scope and delegation. Deny by default.
7. **AI may extract, classify, compare and explain; it must not establish bank truth or authorise financial release.** OCR success is not FDR authenticity. Maturity is not release permission. Human authority plus evidence remains mandatory.
8. **Treat Groq/OpenRouter/free-model access as a prototype and experimentation layer.** Route through a server-side provider abstraction with model allowlists, limits, timeouts, redaction, structured outputs and a no-provider mode. Do not send real FDR/bank documents to unpaid providers without approved privacy review.
9. **Treat external services as not connected until proven.** No fake bank success, no fake “verified” status, no false email/push delivery state, and no claim of STQC/GIGW certification without the relevant formal process.
10. **Build acceptance tests around real failure cases**—cross-institution access, invalid transitions, duplicate submissions, expired sessions, upload attacks, unavailable bank sources, provider rate limits, concurrent approvals and database outages.

## 2. What this product actually needs to solve

The portal should manage the applicable security obligation and its supporting evidence over time. It should connect institution submissions, document evidence, verification, discrepancies/observations, maturity, renewal/replacement, release requests, clearances, decisions and the final release/settlement evidence in one traceable workflow.

### Core capabilities

- Central institution registry with authoritative identifiers and programme/approval context.
- Security deposit / FDR / RTGS instrument register with amounts, dates, source, status and history.
- Secure versioned document uploads and access-controlled downloads.
- Independent evidence verification, with separate workflows for online payments and legacy paper FDRs.
- OCR-assisted field extraction, duplicate hints and discrepancy detection with reviewer confirmation.
- Maturity/renewal tracking, in-app tasks and configurable email/push notifications.
- Release requests driven by a versioned, configurable policy checklist.
- Clearance routing, reviewer observations, maker-checker control and delegated approval.
- Reports, case timelines, source provenance, security logs and audit review.
- Responsive web and Android/iOS application using the same backend contracts and records.

### Do not promise

Do not claim zero manual intervention, instant release, elimination of all fraud, universal real-time bank verification or 100% protection. The portal can reduce manual follow-up and improve verification evidence, not replace official bank confirmation, policy owners or authorised financial decisions.

## 3. Official domain requirements to model carefully

The official AICTE-hosted Approval Process Handbook 2024–2027, Clause 6.46 describes a release path that includes:

- Institution request/application letter for FDR/RTGS release.
- Affidavit 6 with institution and Trust/Society/Company details and instrument/payment details.
- FDR copy; where applicable, DD copies for a corpus fund created by RPGF; or online security-deposit payment proof.
- Latest LoA/EoA.
- Clearances from PGRC, Vigilance Cell and other AICTE cells/bureaus relevant to grants released to the institution.
- For FDR/RPGF, an NOC from the Approval Bureau after the required clearances; for RTGS, a sanction order from the Council.
- If a financial-embezzlement matter with a government body/bank exists, release must wait for the relevant NOC.

**Policy safety:** The research specification reports that the indexed APH text was available but direct opening of the PDF failed during that research run. Before hardcoding a policy rule, re-check the complete current official handbook, corrigenda and notices, then obtain written confirmation from the AICTE policy owner. Penalty percentages, effective dates, exemptions, tenure exceptions and approval delegations must remain draft/blocked until confirmed. Do not infer policy from an LLM.

## 4. Recommended architecture

```text
Responsive Web Client ─┐
                       ├── HTTPS API + Identity + Authorisation
Android/iOS Client ────┘                 │
                                         ▼
                         Modular Backend (one deployable service)
            ┌────────────────────────────────────────────────┐
            │ Identity & Institution Registry                │
            │ Instruments & Lifecycle                        │
            │ Document & Evidence                            │
            │ Verification & Reconciliation                  │
            │ Observations / Clearances / Release Requests    │
            │ Policy Rules & Approvals                       │
            │ Notifications / Reports / Audit                 │
            │ AI Provider Gateway (bounded, optional)        │
            └────────────────────────────────────────────────┘
                   │                │                │
                   ▼                ▼                ▼
              PostgreSQL      Private Object Store   Durable Outbox/Queue
                                                    │
                                                    ├─ OCR / file scanning worker
                                                    ├─ Maturity / deadline worker
                                                    ├─ Notifications worker
                                                    └─ AI extraction / classification worker

External bank/AICTE source adapters: only when access, agreement, documentation,
credentials, test evidence and production approval exist.
```

### Stack decision rules

- First inspect the existing project. Keep the current framework if it is sound and supports the required work; do not rewrite just to follow a fashionable stack.
- **Database:** PostgreSQL is the preferred default for the system of record.
- **Rapid hackathon prototype:** Supabase can provide managed PostgreSQL, Auth and Storage with RLS. The current Free plan has limited capacity and may pause low-activity projects; free projects do not have downloadable managed backups. It is appropriate for a prototype only, not automatically appropriate for sensitive government/financial production records.
- **Backend API:** use the existing backend if present. If none exists, choose a single API framework after inspecting the frontend ecosystem: NestJS/TypeScript when the repo is strongly TypeScript-oriented; FastAPI/Python when Python-based document/OCR processing is a major domain capability. Capture the decision in an ADR rather than building both.
- **Files:** private object storage with scoped access, short-lived download URLs, upload finalisation checks and a document metadata table. Never use public buckets for FDRs/affidavits by default.
- **Background work:** use a durable outbox/job table and worker with idempotency; do not use unreliable fire-and-forget request tasks for critical jobs.
- **Contracts:** versioned REST endpoints with OpenAPI; generate or share types for web/mobile where practical.
- **Deployment:** separate dev, CI, staging/UAT and production configuration. Production hosting must be selected/approved by AICTE IT/security/procurement owners.

### Database/backend selection decision

| Choice | Best fit | Decision for this project |
|---|---|---|
| PostgreSQL (managed or self-hosted) | Relational system-of-record with constraints, transactions, joins, audit and state transitions | **Recommended authoritative database.** Keep SQL schema/migrations portable where practical. |
| Supabase (PostgreSQL + Auth + private Storage + optional Realtime) | Fastest integrated path for a hackathon prototype when the existing stack fits its SDKs | **Recommended prototype candidate**, not automatically production-approved. Test RLS and database grants; high-impact actions use trusted server-side logic. The current Free plan is limited, can pause low-activity projects, and lacks downloadable managed backups. |
| Standalone managed PostgreSQL (for example, Neon or a managed cloud Postgres) | Existing API/backend already owns identity, object storage and business rules | Good option if the repo already has a mature API and you do not need Supabase's integrated Auth/Storage. You must separately implement and test identity, access control, private file storage and operations. |
| Firebase / Firestore as the main record store | App-centric document/NoSQL patterns and realtime client sync | Not the first choice for the authoritative FDR/release ledger: relationships, conditional checklists, cross-entity reporting and complex transactional approval rules fit PostgreSQL more naturally. Firebase may still serve separate client features if justified, but never maintain conflicting sources of truth. |

**Final selection rule:** do not choose a database until the repository audit proves whether a backend/database already exists. If none exists, use PostgreSQL; Supabase is the most convenient prototype path when the codebase matches it. For real institution or financial data, get the hosting/security/data-processing approval and a backup/recovery plan before using any free tier.

### Supabase is not a shortcut around authorisation

If Supabase is selected, use Auth, private Storage and RLS deliberately. Apply least-privilege SQL grants and RLS policies to every exposed table, test allow/deny cases and never ship the service-role/secret key to web or mobile. Sensitive release actions should execute through trusted server-side logic with explicit authorization, state checks and audit events.

## 5. Role catalogue and login design

Use one identity system and route the user to the correct workspace based on server-verified role assignments. Separate login pages for “college/admin” are optional presentation; they must not be the security boundary. Do not allow a user to select their own role, institution, region or approval limit during signup.

The titles below are proposed functional roles, not a claim about AICTE’s official job titles. AICTE must map them to actual units and delegated authorities.

| Functional role | Default scope | Core allowed actions | Must not be able to do |
|---|---|---|---|
| Institution Organisation Admin | One verified institution/legal entity | Invite/deactivate users in that institution, maintain institution contacts, view own cases | Access other institutions, assign AICTE staff roles, approve own release |
| Institution Submitter / Compliance Officer | Own institution and permitted programmes | Create/edit drafts, upload evidence, submit records, respond to observations, request renewals/releases | Mark own FDR bank-confirmed, alter policy, delete submitted history |
| Institution Viewer | Own institution, read-only | View permitted records, timelines, notices and documents | Submit/edit, approve, manage roles or bulk-export beyond scope |
| Intake / Registry Officer | Assigned region/queue | Check completeness, categorise, route and return for corrections | Final approval where separation of duties is required |
| Scrutiny Officer | Assigned cases/region/programmes | Review evidence, raise observations, record reasoned recommendation | Approve the same case when prohibited by maker-checker rules |
| Finance / Verification Officer | Approved verification/source/account scope | Review bank evidence, reconcile authorised ledger/statement, resolve match exceptions | Declare confirmation without evidence or use unrestricted exports |
| Regional Supervisor / Bureau Reviewer | Explicit assigned region/bureau | Assign cases, monitor aging, escalate, review recommendations/reports | Unrestricted cross-region access without an approved grant |
| Competent Authority / Release Approver | Delegated region/programme/decision limit | Approve/reject/defer with reason after checks and step-up authentication | Approve outside delegation, approve own case, bypass required checklist |
| Audit / Compliance Reviewer | Approved read-only scope | Inspect case history, policy versions, decisions, access logs and control evidence | Edit business data or audit events |
| Identity / Access Administrator | Identity and access workflow | Provision/deactivate identity, manage MFA recovery and assign approved roles | Gain routine business-case access or self-grant privileges |
| Platform / Security Operator | Infrastructure plane | Deploy, monitor, rotate secrets, restore backups and respond to incidents | Approve cases or routinely read sensitive documents without separately authorised access |
| Integration Service Identity | One named integration/job scope | Process approved imports or connector calls | Interactive login, broad database access or role administration |
| Participating Bank Verifier (conditional) | Approved bank and assigned confirmation requests | Respond to specific verification requests | View all AICTE cases or approve AICTE releases |

### Authentication recommendations

- Use AICTE-approved OIDC/SSO if one is provided. A provider such as Keycloak is only an engineering option until approved.
- If using Supabase Auth for a hackathon prototype, maintain the same explicit permission model and move sensitive actions server-side.
- Require MFA for internal/privileged roles and step-up authentication before high-impact approvals, policy changes and privilege grants.
- Invitation links should be short-lived, single-use, and tied to the intended institution/role workflow.
- Email verification alone does not establish authority to represent an institution.
- Use secure session handling, rotation/revocation, rate limits, secure recovery, device/session review and immediate access revocation when assignments end.
- Web and mobile must read permissions from trusted backend claims/responses. UI hiding is a usability feature, not access control.

## 6. Core workflow

### A. Institution and user onboarding

1. Institution record is created/imported from an approved authoritative source or provisioned by an authorised intake officer.
2. An institution representative's authority is verified using the approved process.
3. Institution Admin is invited; user accepts the invite and receives only scoped permissions.
4. Every role assignment records requester, approver, scope, effective date, reason and revocation history.

### B. Deposit/FDR registration

1. Submitter creates a draft with institution, programme/obligation context, instrument type, amount, issuing bank/source, instrument identifier, issue date, maturity/validity date and supporting evidence.
2. Server validates schema, relationships, dates and allowed fields; client-supplied `verified`, `approved`, `role`, `region`, or institution ID is never trusted as permission-bearing data.
3. Upload goes to a quarantine/private bucket; file type is checked by content/magic bytes; malware/archive limits are enforced; metadata and hash are recorded.
4. OCR runs asynchronously and returns field candidates with page/region provenance and confidence. User/reviewer confirms or corrects extracted fields; submitted versions remain preserved.
5. Registry/intake check completeness; case is assigned for scrutiny and appropriate verification.

### C. Verification is two distinct pathways

**Online payment / RTGS path:** reconcile using an authorised AICTE/bank payment ledger or source interface when provided. Match amount/reference/credit date/account/context; preserve source batch/transaction IDs, timestamps and response evidence. If no authorised source is available, show “awaiting authorised evidence” or “manual verification required,” not “verified.”

**Legacy paper FDR path:** create a bank-confirmation request via an approved workflow. Record recipient/source, request date, reference, response evidence, officer, result and limitations. OCR, file hashes, institution declaration or an AI authenticity score are not proof of a live FDR, current lien, balance or encashment. No universal public API for all paper FDRs was established in the reviewed research; private integrations may exist but must be confirmed.

Possible evidence outcomes: `DECLARED`, `EXTRACTED`, `REVIEWED`, `BANK_CONFIRMED` (only with approved source), `LEDGER_RECONCILED` (online path only), `INCONCLUSIVE`, `REJECTED`. A rejection/inconclusive response triggers investigation; it does not automatically prove fraud.

### D. Maturity, renewal and replacement

- A scheduled worker finds upcoming maturity/deadline events according to a configurable reminder policy.
- It persists an in-app notification/outbox event first, then dispatches push/email adapters.
- Track `queued`, `provider_accepted`, `delivery_confirmed` when available, `opened`, `acknowledged` separately. Push is best-effort and is not the system of record.
- Renewal/replacement creates a new instrument record and explicit old-to-new lineage. Do not overwrite the prior instrument, evidence or approvals.
- Use a tested scheduler with idempotency and observability; no “simulated clock” in production.

### E. Release request workflow

1. Institution submits request and required evidence.
2. System runs a configurable completeness check against a versioned approved checklist; missing items become explicit outstanding tasks.
3. Intake assigns a case; scrutiny officer reviews the case and raises observations.
4. Relevant clearances are individually requested and recorded with their source, result, date and evidence. No clearance is inferred from a missing record or an empty queue.
5. Independent bank/ledger evidence is reviewed where applicable.
6. The correct final path is selected by instrument type and approved policy: FDR/RPGF NOC path versus RTGS sanction path.
7. Competent authority makes an authorised, reasoned decision within a delegation. The same person cannot act as maker/checker where separation of duties applies.
8. Actual funds/instrument release is performed by the authorised process outside the portal unless a formally approved integration is provisioned. The portal records execution evidence/reference only after trusted confirmation.
9. Case is closed with a full timeline and immutable/append-only controls as appropriate. Prefer the precise term “tamper-evident audit trail” unless the storage controls actually enforce immutability.

Suggested release checklist status values: `SATISFIED`, `NOT_SATISFIED`, `PENDING_SOURCE`, `NOT_APPLICABLE`, each with reviewer, reason, evidence ID and policy version. “All files uploaded” is not equal to clearance or approval.

## 7. Separate state machines

Do not overload a single `status` field with all business states.

- **Instrument record:** `DRAFT → SUBMITTED → INTAKE_REVIEW → SCRUTINY → ACTIVE_TRACKING`, with approved archival/cancellation/supersession transitions.
- **Evidence item:** `DECLARED → EXTRACTED (optional) → REVIEWED → BANK_CONFIRMED or LEDGER_RECONCILED where applicable`; alternative terminal/review states include `INCONCLUSIVE` and `REJECTED` with required reason.
- **Observation/casework:** `OPEN → AWAITING_INSTITUTION → RESPONSE_RECEIVED → UNDER_REVIEW → RESOLVED/CLOSED`, reopening only with reason and audit.
- **Release request:** `DRAFT → SUBMITTED → COMPLETENESS_REVIEW → REQUIRED_CLEARANCES → SCRUTINY/RECOMMENDATION → COMPETENT_AUTHORITY_DECISION → EXECUTION_PENDING → RELEASED/DISCHARGED` only with trusted execution evidence. Alternatives include `RETURNED`, `DEFERRED`, `REJECTED`, `CANCELLED` through authorised transitions.
- **Renewal:** a new instrument record is linked to the old one; preserve both histories.

Every transition must validate previous state, actor permission, scope, policy version, required evidence, separation of duties and concurrency version inside a transaction. Record actor, timestamp, reason code, optional text reason, evidence links, correlation ID and policy version.

## 8. Database domain model

Minimum suggested entities; name and split them to match the existing codebase:

- `institutions`, `institution_programmes`, effective-dated institution/source attributes.
- `users` or identity profiles, `institution_memberships`, `role_assignments`, `permission_catalogue`, scope/delegation metadata.
- `instruments` (FDR/RTGS/deposit obligation), `instrument_versions`, `instrument_relationships` (renewal/replacement lineage).
- `documents`, `document_versions`, `document_access_events`, `ocr_jobs`, `ocr_extractions`, field-level extraction provenance.
- `evidence_items`, `verification_requests`, `verification_responses`, `reconciliation_batches`, `reconciliation_matches`, `observations`.
- `release_requests`, `release_checklist_items`, `clearance_requests`, `approvals`, `execution_evidence`.
- `policy_rules`, `policy_rule_versions`, `policy_sources`, test scenarios; no unreviewed policy auto-publishing.
- `notifications`, `notification_outbox`, `job_runs`, `integration_attempts`.
- `audit_events` (append-only from app perspective), `access_events`, `security_events`, `export_jobs`.
- Optional `ai_jobs`, `model_registry`, `prompt_versions`, `ai_evaluation_results` only if AI features actually need them.

### Data modelling safeguards

- UUID/opaque IDs; FK constraints; unique constraints for authoritative institution IDs and scoped external references; decimal numeric type for financial values; timezone-aware timestamps.
- Separate “institution-reported,” “OCR-extracted,” “bank-confirmed,” and “ledger-reconciled” facts. Never overwrite one trust origin with another.
- Attach evidence source, source timestamp, uploaded version, hash, reviewer and rule version to consequential fields/decisions.
- Use optimistic concurrency (`version`/ETag) and unique idempotency keys for submission, approvals, imports and provider callbacks.
- Keep schemas and migrations version-controlled; use migrations, not manual-only dashboard changes.
- Index scope-filter and join fields used by RLS/policies and queues.
- Consider `pgvector` only if approved-policy search needs semantic retrieval; do not add a vector DB by default.

## 9. AI plan — useful, bounded, measurable

### Tier 1: build first

1. **OCR-assisted extraction:** instrument number, bank/branch, amount, dates, institution name, reference number and relevant identifiers, plus page-level provenance and confidence. Use local/self-hosted OCR where practical, then validate values with deterministic code. Benchmark on a representative, authorised sample before choosing the model.
2. **Document classification:** FDR, request letter, Affidavit 6, LoA/EoA, payment proof, clearance/NOC, sanction order, other. It proposes a label; reviewer confirms.
3. **Field consistency checks:** compare institution name/identifier, amount, instrument ID and dates across uploaded docs and entered form values. Highlight contradictions with the exact source fields/page numbers.
4. **Duplicate and anomaly hints:** exact hashes, normalized instrument/reference matching and fuzzy similarity. Present explainable candidates, not automatic fraud judgments.
5. **Plain-language case summaries:** summarise an assigned case's status, outstanding evidence and reasons with links to source records; redact sensitive fields where possible.

### Tier 2: after core workflow is reliable

6. **RAG over approved policy corpus:** ingest official handbook/corrigenda as versioned documents; every answer returns clause/source/version and effective date. If no applicable source is found, say that a policy owner must decide.
7. **Reviewer copilot:** propose observations, draft institutional follow-up requests and explain missing checklist items. Staff reviews before sending or recording.
8. **AI model evaluation dashboard:** field-level extraction accuracy, exact-match accuracy for IDs/dates/amounts, false mismatch rate, reviewer correction rate, latency and provider failure rate. Record model and prompt versions.

### Tier 3: defer until data and governance justify it

- Predictive maturity/processing workload, prioritisation suggestions, or trend analytics—only after a representative, lawful dataset and evaluation plan exist.
- Agentic orchestration/multi-agent loops, arbitrary SQL generation and automated financial decisions are not first-release priorities.

### AI architectural guardrails

- All LLM requests pass through a single server-side provider interface. Example capabilities: `extract_fields`, `classify_document`, `compare_fields`, `summarise_case`, `retrieve_policy_answer`.
- Use JSON Schema/Pydantic/Zod validation; discard/repair invalid output within a small bounded retry count; never directly execute model-produced SQL or state transitions.
- Record provider, model ID, prompt version, latency, token counts, success/error class and redaction outcome; avoid sensitive raw prompt logging.
- Strict timeout, concurrency budget, per-user/institution quotas, retry cap, exponential backoff and circuit breaker. Do not retry until free-tier quota is drained.
- Provider/model IDs and limits are environment/configuration, not hardcoded assumptions. A provider outage yields a transparent “AI processing unavailable” state; manual workflow remains usable.
- Apply prompt-injection defence to uploaded documents: treat their contents as untrusted data; never let document text issue tool instructions or override system/developer policy.
- Human review remains mandatory for financial facts, fraud suspicion, policy interpretation and release decisions.

## 10. Model-provider options: what “free” realistically means

Free quotas, model names, availability and terms can change. Verify the provider dashboard and current official terms at implementation time.

| Option | Good use | Limit / risk | Recommendation |
|---|---|---|---|
| **Groq API** | Fast inference for low-sensitivity structured extraction, case summaries or reviewer drafts during prototype development | Rate limits vary by model and account. Groq says inference inputs/outputs are not retained by default, but may be temporarily retained for reliability/abuse investigations for up to 30 days unless Zero Data Retention is enabled; data location documented as US GCP. | Keep behind a provider adapter. Use only after privacy approval; prefer redacted/synthetic input for hackathon demos. |
| **OpenRouter free models** | Trying several open models from one API and comparing schema extraction, cost and latency | Official pricing currently shows free models and a free-account 50 requests/day limit; provider routing/model endpoints and limits vary. Free models are not a production SLA. Underlying provider data terms may differ. | Excellent experimentation router, not a production guarantee. Select explicit provider/data policy and test failure handling. |
| **Gemini API unpaid quota** | Prototype tasks on non-sensitive content, structured-output experiments | Google's terms say unpaid-services content can be used to improve products and can be reviewed by humans; docs warn not to submit sensitive/confidential/personal information to unpaid services. | Do not send real institution/FDR/bank records to the unpaid API. Use synthetic or redacted data unless terms and legal review support use. |
| **Hugging Face Inference Providers** | Small experiments/benchmarking across supported models | Official docs list $0.10/month for free users, subject to change; not meaningful as an unlimited production backend. | Optional experiment path, not a core runtime dependency. |
| **Local/self-hosted OCR/LLM** | Sensitive document processing where infrastructure capacity and licensing permit | Needs compute, patching, latency/accuracy evaluation and operational support; model output still requires validation. | Prefer local OCR for the sensitive first pass; use local LLM only if the team can operate and benchmark it. |

### Recommended hybrid AI setup

- **Default document pipeline:** local/self-hosted OCR → deterministic field normalization and validation → optional approved LLM for a redacted extracted-text subset → schema validation → reviewer confirmation.
- **Prototype LLM gateway:** Groq primary for allowed low-sensitivity tasks; OpenRouter as opt-in comparison/fallback only if provider policy allows; Gemini unpaid quota only for synthetic/non-sensitive material; otherwise AI disabled and manual workflow available.
- **Production:** use only providers/contracts and regions approved by AICTE. Never make production depend on a free model quota or upload real FDR files to an unapproved provider.
- Choose the model from measured accuracy on your own authorised evaluation set, not benchmark rankings or model-name popularity.

## 11. Notifications and jobs

- Use a durable notification/outbox table inserted in the same transaction as the business event.
- A worker dispatches email, FCM, APNs and Web Push only when the provider and credentials are configured and the environment allows sending.
- Persist event state and each attempt; use idempotency to avoid duplicates.
- Store no FDR number or sensitive financial details in lock-screen push previews by default.
- A missing provider key means the adapter is `DISABLED` or `NOT_CONFIGURED`, never “sent successfully.”
- Jobs should have timeouts, bounded retries, backoff, dead-letter/review state, idempotency and metrics.

## 12. Security, privacy and audit requirements

Minimum baseline:

- Use OWASP ASVS 5.0.0 as a versioned web/API verification checklist; use API Security Top 10 to prioritise object-level and function-level access, authentication, property exposure, resource exhaustion and unsafe external APIs. Use OWASP MASVS for mobile.
- TLS, secure headers, secret rotation, private document storage, short-lived signed URLs, restrictive CORS, safe error responses and rate limits.
- Explicit server-side permission checks for every resource and sensitive field; RBAC + ABAC; no trusted scope taken from form body/query params.
- RLS and SQL grants if Supabase/exposed Postgres API is used; separate app role from migration/admin role. Never expose service/secret credentials in client builds.
- Upload defence: MIME/magic-byte verification, extension allowlist, size/page limits, archive bomb limits, malware scanning, quarantine, sanitisation and OCR worker isolation.
- Append-only audit event interface and restricted central logs. A SHA-256 hash by itself is not immutable storage; use access controls, independent log forwarding, signed checkpoints, retention and sequence-gap alerting.
- Data inventory, purpose and retention rules, privacy notice, data minimisation, masking, rights/grievance workflow and vendor review. Confirm DPDP Act/Rules provision-level applicability and commencement with counsel; do not say “DPDP compliant” just because a notice or consent checkbox exists.
- CERT-In directions include log retention and incident-reporting requirements for covered entities. Confirm AICTE/operator applicability and the current playbook with security/legal owners.
- Backup and restore test; recovery targets approved by the service owner; include database, documents, policy versions, audit data and encryption-key recovery.
- Threat modelling for cross-tenant leaks, malicious uploads, privilege escalation, AI prompt injection, insider abuse, provider outage and release/approval race conditions.

## 13. API and integration design

Create an OpenAPI contract and use it for web/mobile integration. Suggested resource groups:

- `/v1/me`, `/v1/me/permissions`, `/v1/sessions`
- `/v1/institutions`, `/v1/institution-memberships`, `/v1/programmes`
- `/v1/instruments`, `/v1/instruments/{id}/submit`, `/v1/instruments/{id}/timeline`
- `/v1/documents/upload-intents`, `/v1/documents/{id}/finalise`, `/v1/documents/{id}/download-intent`
- `/v1/verification-requests`, `/v1/verification-responses`, `/v1/reconciliation-batches`
- `/v1/observations`, `/v1/observations/{id}/responses`, `/v1/observations/{id}/resolve`
- `/v1/release-requests`, `/v1/release-requests/{id}/checklist`, `/v1/release-requests/{id}/decision`
- `/v1/clearances`, `/v1/approvals`, `/v1/execution-evidence`
- `/v1/notifications`, `/v1/reports`, `/v1/audit-events` (scoped)
- `/v1/ai/jobs`, `/v1/admin/policies`, `/v1/admin/integrations` (restricted, if needed)

Use consistent pagination, filters, validation errors and request IDs. State-changing calls need idempotency keys; stale requests should return an explicit conflict using ETags/version numbers. Add integration adapters only when official endpoints, agreements, sandbox credentials, test evidence and production owner exist.

## 14. Implementation sequence

### Phase 0 — Repository audit (read-only)

- Inventory web and mobile apps, stack versions, app entry points, routes, UI components and current navigation.
- Find hardcoded arrays, mock APIs, fixtures, fake loading timers, localStorage-only persistence and stubbed providers.
- Trace a sample user journey from UI event to data service and identify exactly where persistence breaks.
- Check auth, permission enforcement, backend existence, database configuration, secrets handling and test setup.
- Run current tests/builds and record failures before changes.
- Deliver `PROJECT_AUDIT.md`, `CURRENT_ARCHITECTURE.md`, `DATA_FLOW_MAP.md`, mock-data inventory, risk list and proposed architecture decision.

### Phase 1 — Persistence and identity vertical slice

- Add real database configuration and versioned migrations.
- Implement institutions, users/memberships/role assignments and instrument register.
- Implement real auth integration and `/me` + permission response.
- Connect one complete web CRUD path and one mobile CRUD path to the same backend; restart app and prove records persist.
- Remove mock data from normal production execution; isolate fixtures in test/dev scripts only.

### Phase 2 — Secure domain workflows

- Implement separate instrument/evidence/observation/release states.
- Implement permission engine (RBAC + ABAC) and maker-checker invariants.
- Add case timeline, observations, required checklist, clearances, decisions and release evidence.
- Add authorization negative tests for cross-institution and cross-region reads/writes.

### Phase 3 — Document pipeline

- Private upload storage, metadata/version records, scanning/quarantine, authorised downloads, hash and OCR jobs.
- Field-level provenance, reviewer correction and clear “extracted vs verified” visual labels.
- Test malformed PDFs, oversize, unsupported MIME, duplicate documents and unauthorised download.

### Phase 4 — Maturity and notifications

- Tested scheduler, durable outbox, idempotent queue worker, in-app notifications, provider adapters and delivery states.
- Configure actual email/push only using credentials supplied by the developer/org; otherwise show not configured.

### Phase 5 — AI gateway and bounded use cases

- Add provider abstraction, key configuration, timeouts, quotas, circuit breakers and structured-output validators.
- Add OCR extraction/classification/field comparison and optional case summary.
- Evaluate on authorised synthetic/approved documents and record measured accuracy. No AI-generated release decision.

### Phase 6 — Security and end-to-end quality

- Unit, integration, DB/migration, RLS/authorization, file security, web E2E and mobile E2E tests.
- SAST, dependency audit, secret scan, accessibility checks, API contract tests and backup/restore rehearsal.
- Validate that web/mobile see the same record, timeline, document access and current role permissions.

### Phase 7 — Deployment and operator handover

- `.env.example` without secrets; clear setup/migration/seed/test commands; separate environment templates.
- CI checks, deployment workflow, logs/metrics, worker health, database backup guidance and incident/runbook notes.
- Document unprovisioned external integrations and decisions requiring AICTE approval.

## 15. Definition of done

A feature is not “done” because a page renders. It is done when:

- Data is written to PostgreSQL and survives refresh, app restart and session change.
- Both web and mobile use the same API and show consistent record state.
- Authentication is real; protected endpoints reject unauthenticated requests.
- Institution A cannot access Institution B's record/document by changing IDs, URL, search filters, exports or notification links.
- Server rejects client attempts to set protected fields such as `role=admin`, `verified=true`, `approved=true` or arbitrary institution/region scope.
- Workflow transitions are allow-listed, transactional, audited and concurrency-safe.
- Evidence extraction is labelled separately from bank/ledger verification.
- Required clearance and approval steps cannot be silently skipped.
- Release closure requires trusted execution evidence, not just a maturity date or approval screen.
- API secrets do not appear in frontend bundles, mobile assets, logs or Git history.
- Provider/API failure, quota exhaustion and unavailable integration produce truthful failure states; manual workflow remains possible.
- Tests pass, migration instructions are reproducible, and the README describes actual—not aspirational—functionality.

## 16. Key research references

**AICTE / official domain**

- AICTE Approval Process Handbook (2024–2027), Clause 6.46, “Release of Security Deposit”: https://www.aicte.gov.in/sites/default/files/APH%20Final.pdf
- PIB announcement of AICTE APH 2024–2027: https://www.pib.gov.in/Pressreleaseshare.aspx?PRID=1983013&lang=2&reg=48
- Internal user-supplied research baseline: *AICTE FDR Portal — Deep Research & Production Specification v3.0*, revision 23 October 2026. This document itself warns that it is not an official approval and records unresolved integration/policy decisions.

**Backend / database**

- Supabase pricing and Free-plan limits: https://supabase.com/pricing
- Supabase production checklist: https://supabase.com/docs/guides/deployment/going-into-prod
- Supabase PostgreSQL Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Supabase Auth: https://supabase.com/docs/guides/auth
- Supabase Storage access control: https://supabase.com/docs/guides/storage/security/access-control
- Supabase backups: https://supabase.com/docs/guides/platform/backups

**AI providers / OCR**

- Groq supported models: https://console.groq.com/docs/models
- Groq rate limits: https://console.groq.com/docs/rate-limits
- Groq data handling: https://console.groq.com/docs/your-data
- OpenRouter pricing/free-model limits: https://openrouter.ai/pricing
- OpenRouter model/provider selection: https://openrouter.ai/docs
- Gemini API rate limits: https://ai.google.dev/gemini-api/docs/rate-limits
- Gemini API unpaid-service data terms: https://ai.google.dev/gemini-api/terms
- Gemini structured outputs: https://ai.google.dev/gemini-api/docs/structured-output
- Hugging Face Inference Providers pricing: https://huggingface.co/docs/inference-providers/pricing
- PaddleOCR official project (OCR capabilities and updates): https://github.com/PaddlePaddle/PaddleOCR

**Security / privacy / operations**

- OWASP ASVS 5.0.0: https://asvs.owasp.org/
- MeitY DPDP Rules 2025 and commencement timeline: https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa?pageTitle=Digital-Personal-Data-Protection-Rules-2025
- CERT-In Directions (28 April 2022): https://www.cert-in.org.in/PDF/CERT-In_Directions_70B_28.04.2022.pdf

**Agent workflow library**

- Agency Agents repository: https://github.com/msitarzewski/agency-agents
- Backend Architect agent: https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-backend-architect.md
- Codebase Onboarding Engineer: https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-codebase-onboarding-engineer.md
- Identity & Access Engineer: https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-identity-access-engineer.md
- Database Reliability Engineer: https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-database-reliability-engineer.md
- AI Engineer: https://github.com/msitarzewski/agency-agents/blob/main/engineering/engineering-ai-engineer.md

## 17. Using Agency Agents without overcomplicating the build

The linked [Agency Agents](https://github.com/msitarzewski/agency-agents) project is a library of specialist agent prompts and install/conversion scripts. It does not provide an AICTE backend, database, bank integration or completed application. For this task, use a small, relevant roster: `codebase-onboarding-engineer`, `software-architect`, `backend-architect`, `database-reliability-engineer`, `identity-access-engineer`, `mobile-app-builder`, `ai-engineer`, `devops-automator` and `code-reviewer`. Verify names against the checked-out repo's agent list before installing. The repository documents OpenCode support and warns that some OpenCode versions may silently drop agents beyond their registration limit, so do not install every agent merely because the library contains them.

A safe sequence is: inspect the repo → run the install script's list/dry-run functions → install only the selected agents → start with the Codebase Onboarding Engineer in read-only mode → hand off specific, bounded implementation/review tasks. Treat agent recommendations as proposals; require code inspection, tests and evidence before accepting changes.

## 18. Final recommendation

Your first milestone should be a genuinely working vertical slice: **institution login → create a real instrument record → upload a private document → persist it in PostgreSQL/object storage → view it from web and mobile → enforce institution-specific access → record an auditable state change.** Then expand the verification, maturity and release workflow. This proves the architecture before AI or integrations make the system more complex.
