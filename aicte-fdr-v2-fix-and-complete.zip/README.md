# AICTE FDR Portal — v2 "Fix, complete, make it beautiful" package

Drop this folder's contents into the **root of your existing repo** (merge; files here win), then start Claude Code in that folder. It **replaces** the earlier package's design files and adds the audit, the 13-role authentication matrix, the new theme and the v2 prompts.

## Read in this order
1. `docs/AUDIT_REPORT.md` — what the live inspection found (mobile does not start, web is hard-coded, no auth, simulation features still present) and what is missing.
2. `design/preview.html` — **open this in a browser**: the reference-matched "Lavender Ledger" look (9 mobile screens + web). Compare with `design/reference/reference-sheet.png`; research and measurements in `docs/DESIGN_RESEARCH.md`.
3. `docs/MASTER_PROMPT_V2.md` — the master prompt (streams R0–R9, 29 acceptance gates, anti-patterns).
4. `docs/AUTH_ROLES_MATRIX.md` — roles, authentication flows, landing screens, permissions (build data).
5. `docs/PHASED_PROMPTS_V2.md` — paste prompts A → K into Claude Code one at a time (fresh session each).
6. **`docs/MASTER_PROMPT_COMPLETE.md` — everything above merged into one self-contained prompt** (rebuild with `python3 -I scripts/build_complete_prompt.py`).

## What is new vs the first package
| Area | v1 | v2 |
|---|---|---|
| Design | dark #050505 / violet / cyan, Liquid Glass | reference-matched light lavender: white 20-px cards, azure duotone icons, black pill buttons, soft-red pill, floating pill tab bar (headless tabs), thin-progress top bar with role pill, hero card with mascot, original "Kosh" character; dark is a full counterpart |
| Tokens | `tokens.*` dark | `design/tokens.ts` (source) → `tokens.css` generated; `check_tokens.py` asserts 192 contrast pairs and parity; `build_preview.py` regenerates the preview |
| Roles/auth | spec only | `AUTH_ROLES_MATRIX.md`, server-built navigation manifest, staging users, per-role e2e |
| Guards | hooks for flags/float money/icons | + raw colours, removed features, client-side role state; `scripts/forbidden-strings.mjs` for source and built bundles |
| Agents/skills | reviewer, security-auditor, spec-auditor, design-reviewer | + `role-tester`, `role-walkthrough` skill, updated `design-reviewer` / `ui-screenshot-qa` |

## Checks you can run right now (no repo needed)
```
python3 -I design/check_tokens.py                  # tokens parity + contrast
python3 -I design/check_tokens.py --write          # regenerate tokens.css colours from tokens.ts
python3 -I design/build_preview.py                 # regenerate design/preview.html
node scripts/forbidden-strings.mjs <dir> [<dir>]   # removed-feature / fake-data scan
```

## Important limits
- The inspection saw the running app only through a browser: no source, no tests, no database, no authenticated API calls, no physical device. The first job of Claude Code (stream R0) is to inventory the repo and measure the real state.
- The reference sheet is matched for look, layout and behaviour. This package does not use its product name, logo, wordmark, mascot or illustrations (the product has its own: `fdr·portal` and the mascot Kosh), and the reviewer agent fails anything that reproduces them.
- Policy facts (penalties, reminder windows, delegation limits) stay draft/BLOCKED until AICTE answers `docs/OPEN_DECISIONS.md`.
