#!/usr/bin/env python3
"""check_tokens.py — design-token guard for "Lavender Ledger" (v2).

  python3 -I design/check_tokens.py           # verify tokens.css <-> tokens.ts parity + WCAG contrast (CI, exit 1 on failure)
  python3 -I design/check_tokens.py --write   # regenerate the colour block of tokens.css from tokens.ts, then verify

tokens.ts is the source of truth for colour. tokens.css carries the same values as CSS custom properties
(light = :root, dark = :root[data-theme="dark"] and the prefers-color-scheme fallback)."""
import re, sys, pathlib

here = pathlib.Path(__file__).parent
ts = (here / "tokens.ts").read_text()
css_path = here / "tokens.css"

def ts_obj(name):
    m = re.search(r"export const %s = \{(.*?)\} as const;" % name, ts, re.S)
    if not m:
        sys.exit(f"tokens.ts: object {name} not found")
    return dict(re.findall(r"(\w+):\s*'(#[0-9a-fA-F]{6})'", m.group(1)))

light, dark = ts_obj("light"), ts_obj("dark")
m3l, m3d = ts_obj("m3Light"), ts_obj("m3Dark")
kebab = lambda k: re.sub(r"([A-Z])", lambda m: "-" + m.group(1).lower(), k)

def block(theme):
    return "\n".join(f"  --{kebab(k)}: {v};" for k, v in theme.items())

START, END = "/* >>> GENERATED COLOUR TOKENS (design/check_tokens.py --write) >>> */", "/* <<< GENERATED COLOUR TOKENS <<< */"

def generated():
    return (
        f"{START}\n:root {{\n  color-scheme: light;\n{block(light)}\n}}\n"
        f":root[data-theme=\"dark\"] {{\n  color-scheme: dark;\n{block(dark)}\n}}\n"
        f"@media (prefers-color-scheme: dark) {{\n  :root:not([data-theme=\"light\"]) {{\n    color-scheme: dark;\n"
        + "\n".join("  " + l for l in block(dark).splitlines()) + f"\n  }}\n}}\n{END}"
    )

if "--write" in sys.argv:
    txt = css_path.read_text() if css_path.exists() else f"{START}\n{END}\n"
    if START in txt:
        txt = re.sub(re.escape(START) + r".*?" + re.escape(END), lambda _: generated(), txt, flags=re.S)
    else:
        txt = generated() + "\n" + txt
    css_path.write_text(txt)
    print("tokens.css colour block regenerated")

css = css_path.read_text()
def css_vars(sel_regex):
    m = re.search(sel_regex, css, re.S)
    return {} if not m else {k: v.lower() for k, v in re.findall(r"--([\w-]+):\s*(#[0-9a-fA-F]{6})", m.group(1))}
css_light = css_vars(r":root \{(.*?)\n\}")
css_dark = css_vars(r":root\[data-theme=\"dark\"\] \{(.*?)\n\}")
css_dark_mq = css_vars(r"@media \(prefers-color-scheme: dark\) \{\s*:root:not\(\[data-theme=\"light\"\]\) \{(.*?)\n  \}")

fail = []
for name, t, c in (("light", light, css_light), ("dark", dark, css_dark), ("dark@media", dark, css_dark_mq)):
    for k, v in t.items():
        if c.get(kebab(k)) != v.lower():
            fail.append(f"parity {name}.{k}: ts {v} != css {c.get(kebab(k))}")
if set(light) != set(dark):
    fail.append(f"light/dark key mismatch: {sorted(set(light) ^ set(dark))}")

def lin(c):
    c /= 255
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
def lum(h):
    h = h.lstrip("#"); r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
def cr(a, b):
    x, y = sorted((lum(a), lum(b)), reverse=True)
    return (x + 0.05) / (y + 0.05)

checks = []
def need(theme, t, fg, bg, mn, label=None):
    checks.append((theme, label or f"{fg} on {bg}", cr(t[fg], t[bg]), mn))

for theme, t in (("light", light), ("dark", dark)):
    grounds = ("canvas", "surface", "surfaceMuted", "field")
    for g in grounds:
        for fg in ("text1", "text2", "text3"):
            need(theme, t, fg, g, 4.5)
        need(theme, t, "primary", g, 4.5)            # links, icons, active labels
        need(theme, t, "outline", g, 3.0)            # control borders / unchecked toggle
        need(theme, t, "focus", g, 3.0)              # focus ring
        for s in ("ok", "warn", "info", "error", "pending", "neutral"):
            need(theme, t, s, g, 4.5)                # status text/icons on neutral grounds
    need(theme, t, "onPrimary", "primary", 4.5)
    need(theme, t, "onPrimaryContainer", "primaryContainer", 4.5)
    need(theme, t, "primary", "primaryContainer", 4.5, "active tab label (primary on primaryContainer)")
    need(theme, t, "primary", "primarySoft", 4.5, "primary on primarySoft")
    need(theme, t, "text1", "primarySoft", 4.5, "text1 on primarySoft")
    need(theme, t, "onInk", "ink", 4.5)
    need(theme, t, "onRoleFill", "roleFill", 4.5, "role pill text")
    for g in ("canvas", "surface", "surfaceMuted", "field"):
        need(theme, t, "azure", g, 3.0, f"azure icon on {g} (non-text 3:1)")
    need(theme, t, "azure", "primaryContainer", 3.0, "azure icon on active capsule")
    need(theme, t, "onDanger", "danger", 4.5)
    need(theme, t, "onDangerContainer", "dangerContainer", 4.5)
    for s, c, on in (("ok", "okContainer", "onOkContainer"), ("warn", "warnContainer", "onWarnContainer"),
                     ("info", "infoContainer", "onInfoContainer"), ("error", "errorContainer", "onErrorContainer"),
                     ("pending", "pendingContainer", "onPendingContainer"), ("neutral", "neutralContainer", "onNeutralContainer")):
        need(theme, t, on, c, 4.5)
        need(theme, t, s, c, 4.5, f"{s} icon/text on {c}")
    need(theme, t, "outline", "surface", 3.0)

for theme, t in (("m3Light", m3l), ("m3Dark", m3d)):
    for fg, bg in (("onPrimary", "primary"), ("onPrimaryContainer", "primaryContainer"), ("onSecondary", "secondary"),
                   ("onSecondaryContainer", "secondaryContainer"), ("onTertiary", "tertiary"),
                   ("onTertiaryContainer", "tertiaryContainer"), ("onError", "error"), ("onErrorContainer", "errorContainer"),
                   ("onSurface", "surface"), ("onSurfaceVariant", "surfaceVariant"), ("onBackground", "background"),
                   ("inverseOnSurface", "inverseSurface")):
        need(theme, t, fg, bg, 4.5)
    for bg in ("surface", "surfaceContainerLowest", "surfaceContainer"):
        need(theme, t, "outline", bg, 3.0)
        need(theme, t, "primary", bg, 4.5)
        need(theme, t, "onSurfaceVariant", bg, 4.5)

for theme, label, r, mn in checks:
    if r < mn:
        fail.append(f"contrast {theme} {label}: {r:.2f} < {mn}")

# Brand rules that must stay true
if cr(light["ink"], light["canvas"]) < 12: fail.append("ink pill must be near-black on canvas (>= 12:1)")
if cr(light["primary"], light["surface"]) < 5: fail.append("primary blue on white should stay >= 5:1")
for k in ("hairline", "textDisabled"):
    pass  # decorative / disabled only; deliberately not asserted

print(f"{len(checks)} contrast checks. primary blue on white {cr(light['primary'], light['surface']):.2f}:1 | "
      f"active-tab label {cr(light['primary'], light['primaryContainer']):.2f}:1 | ink pill {cr(light['onInk'], light['ink']):.2f}:1")
if fail:
    print("\n".join(fail)); sys.exit(1)
print("tokens OK")
