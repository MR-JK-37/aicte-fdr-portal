#!/usr/bin/env python3
"""Builds docs/MASTER_PROMPT_COMPLETE.md: one self-contained prompt = master prompt v2 + auth/roles matrix + design spec + tokens + research decisions + phased prompts.
   python3 -I scripts/build_complete_prompt.py   (run from the repo root; re-run whenever a source file changes)"""
import pathlib
root = pathlib.Path(__file__).resolve().parent.parent
parts = [
    ("PART 1 — MASTER PROMPT V2 (work order, gates, streams)", "docs/MASTER_PROMPT_V2.md"),
    ("PART 2 — AUTHENTICATION, ROLES, NAVIGATION (build data)", "docs/AUTH_ROLES_MATRIX.md"),
    ("PART 3 — DESIGN SPEC (reference-matched 'Lavender Ledger')", "design/DESIGN_SPEC.md"),
    ("PART 4 — DESIGN TOKENS (tokens.ts — source of truth for colour, shape, type)", "design/tokens.ts"),
    ("PART 5 — DESIGN RESEARCH (measurements and platform decisions)", "docs/DESIGN_RESEARCH.md"),
    ("PART 5b — EXPO GO VS DEVELOPMENT BUILD (what can run where)", "docs/EXPO_GO_VS_DEV_BUILD.md"),
    ("PART 6 — PHASED PROMPTS (paste one per fresh session)", "docs/PHASED_PROMPTS_V2.md"),
    ("PART 7 — AUDIT OF THE FIRST BUILD (what is broken and missing)", "docs/AUDIT_REPORT.md"),
]
head = """# MASTER_PROMPT_COMPLETE — AICTE Security Deposit / FDR Portal (SIH PS 26265): fix, complete, match the reference design

You are Claude Code. This single file is the complete work order. Read ALL of it before acting. The same material also exists as separate files in the repo (docs/, design/); they are identical copies and remain authoritative if you edit anything. Also read, on demand: `CLAUDE.md`, `docs/spec/SPEC_v3.md`, `docs/MASTER_PROMPT.md` (v1 module behaviour F-01…F-28, M-01…M-21), `design/preview.html` (render it with Playwright and LOOK at it), `design/reference/reference-sheet.png` (the owner's target look; style reference only — never reproduce its brand assets).

How to run: start with PART 6 prompt A (plan only), then B…K one per fresh session. Never skip an exit gate. Never claim anything you have not run. Open the app and read screenshots after every UI change.

"""
out = [head]
for title, rel in parts:
    body = (root / rel).read_text()
    lang = "typescript" if rel.endswith(".ts") else ""
    body = f"```{lang}\n{body}\n```" if lang else body
    out.append(f"\n\n---\n\n# {title}\n\n(source: `{rel}`)\n\n{body}\n")
(root / "docs" / "MASTER_PROMPT_COMPLETE.md").write_text("".join(out))
print("docs/MASTER_PROMPT_COMPLETE.md", sum(len(x) for x in out), "chars")
