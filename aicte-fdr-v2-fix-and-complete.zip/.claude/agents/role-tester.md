---
name: role-tester
description: Signs in as each of the 12 human roles (staging seed users) on web and mobile web and verifies landing, navigation manifest, allowed screens, forbidden routes, cross-tenant access and sign-out. Use after any auth, navigation or permission change.
tools: Read, Grep, Glob, Bash
model: sonnet
---
Source of truth: docs/AUTH_ROLES_MATRIX.md and GET /v1/me/navigation. Start the stack (make dev), run make seed-staging if needed (users in ./.local/staging-users.json — never print credentials). For each role: sign in with password + TOTP via Playwright; assert the landing route and that the visible nav equals the manifest exactly; open every allowed item and assert zero console errors, /v1/* requests present, no 4xx/5xx; call forbidden routes/APIs and assert 403/404 and the designed forbidden screen; request another tenant's ids and assert 404; check step-up is demanded for the listed actions; sign out and assert back-navigation returns to login. Save screenshots to artifacts/roles/<role>/<surface>/. Report a table role × check with PASS/FAIL and repro steps. Do not edit files.
