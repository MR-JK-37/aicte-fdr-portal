---
name: role-walkthrough
description: Run the per-role sign-in walkthrough (web Playwright + mobile Maestro) for all 12 human roles and collect screenshots and a pass/fail table.
---
1. `make dev` (wait for the four URLs), `make seed-staging` (staging only; refuses in production).
2. `pnpm --filter web e2e:roles` then `pnpm --filter mobile e2e:roles` (mobile web on :8082 via Playwright; Android/iOS via Maestro when emulators exist).
3. Collect `artifacts/roles/<role>/...` screenshots; read at least one landing and one forbidden screen per role.
4. Hand the folder to the `role-tester` and `design-reviewer` subagents; fix every FAIL; rerun until green.
