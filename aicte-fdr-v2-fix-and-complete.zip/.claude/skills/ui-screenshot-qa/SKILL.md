---
name: ui-screenshot-qa
description: Capture and check the UI screenshot matrix (web viewports x themes x locales; mobile devices) against design/preview.html and design/DESIGN_SPEC.md.
---
1. Web: `pnpm --filter web e2e:visual` -> `artifacts/screenshots/web/<route>__<w>x<h>__<theme>__<locale>.png` for widths 390, 768, 1280, 1920; themes light and dark (+ reduced-transparency and increased-contrast for 1280); locales en, hi, ta.
2. Mobile: iOS simulator (small/large iPhone + iPad) and Android emulator (phone + tablet/foldable), light/dark, font scale 100% and 200%. Mobile web at :8082 via Playwright for quick checks.
3. READ the images. Compare with `design/preview.html` (render it with Playwright). Check tokens-only colours, black-pill primary, floating tab bar, Kosh empty states, contrast, clipped Hindi/Tamil, touch targets, icon-source rules, console/network errors.
4. Hand the folder to `design-reviewer`; fix every FAIL.
