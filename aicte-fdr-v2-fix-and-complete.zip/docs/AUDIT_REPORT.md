# AUDIT_REPORT.md — live inspection of the first build (24 Oct 2026)

**What was inspected:** the running app on the owner's machine, through Chrome: web portal `http://localhost:3000` (all 11 top-level tabs, the utility chips, the role dropdown, network traffic), FastAPI docs `http://localhost:8000/docs` and the full OpenAPI document `/v1/openapi.json` (89 routes), and the mobile web preview `http://localhost:8082` (including the Metro bundle response).
**What was NOT inspected (so nothing below claims it):** source code, tests, database/RLS, Docker config, authenticated API behaviour (no credentials were used or entered), Expo Go on a physical device, push delivery. Those need the repository; Phase R0 of the v2 prompt starts by auditing them.

**Verdict:** the backend is a credible skeleton. The web app is a **static, hard-coded mock** that does not talk to it. The mobile app **does not run** (bundle fails). Authentication for the 13 roles is **not implemented in any client**. The build is **not** "completed" against the v3 spec; it is roughly a quarter of the way there, with the right bones.

---

## 1. Findings (ranked)

### Critical
| ID | Finding | Evidence | Why it matters |
|---|---|---|---|
| A-01 | **Mobile app does not start.** The Metro bundle request returns HTTP 503 `UnableToResolveError: react-native-web/dist/exports/AppRegistry`, and the entry resolved is the default `./apps/mobile/node_modules/expo/AppEntry` (not `expo-router/entry`). Metro was started from the monorepo root (`…/SIH`), `react-native-web` is not installed/resolvable under pnpm, and `main` is not the router entry. `http://localhost:8082` is a blank white page. The Expo Go deep link will hit the same bundler (not verified on a device). | `AppEntry.bundle?platform=web…` → 503 JSON | There is no mobile app to review, and every mobile requirement is unmet. |
| A-02 | **The web portal makes no calls to the backend.** During page load and navigation of all 11 tabs, the only requests to `localhost:8000` were the Swagger page's own `openapi.json`. Every number, table row, status and button is hard-coded in the front end. | Network log: no `/v1/*` XHR/fetch from `:3000` | The "real, real-time" requirement is unmet. The dashboard is a picture. |
| A-03 | **No authentication in the web UI and no real roles.** There is no sign-in screen, no password field, no MFA, no session. The "role" is a client-side dropdown with five options (`Institution`, `Scrutiny Officer`, `Competent Authority`, `Bureau Admin`, `Auditor`). Anyone can switch to Competent Authority in one click. `Bureau Admin` is not a spec role, and "Institution" is one generic entry where the spec has three (Org Admin, Submitter, Viewer). Intake/Registry, Finance/Verification, Regional Supervisor, IAM Admin, Platform Operator, Bank Verifier and the integration identity do not exist in the UI. The API does have `/auth/login`, `/auth/logout`, `/auth/step-up`, `/me`, `/me/permissions` — none are used. | Role `<select>` options enumerated; no `input[type=password]` in DOM | Defeats the whole security model (SPEC §4–5). |
| A-04 | **Simulation and demo features are present in the UI** although they were explicitly removed from scope: an **"AI Voice Call"** header chip and **per-row "AI Voice Call"** buttons in the reminder queue; a **"Clock Live"** chip; a **"SIMULATION"** badge next to the product name; **"Simulate Statement Ingestion"**; **"Simulate Tamper"** on every audit block; **"Browse File (Demo FDR)"**. | Visible on Submit FDR, Bank Verification, Reminder Ladder, Audit Chain, header | Violates non-negotiable #1; would be disqualifying in a real review. |

### High
| ID | Finding | Evidence |
|---|---|---|
| A-05 | **Dishonest status displays.** Admin & Connectors shows every connector **HEALTHY** with latencies (e.g. bank gateway 342 ms, PFMS, DigiLocker, FCM, APNs) and "checked" timestamps although no connector is configured. Audit page shows **"Chain integrity 100% valid"** without a verification run. Reminder page is titled **"Statutory escalation ladder"** although the schedule is unapproved (D-10). | Admin, Audit, Reminder screenshots |
| A-06 | **Release screen implies automatic eligibility.** "Eligible for Release" with an all-green checklist and a **"Sign & Issue QR Certificate"** step are hard-coded. Maturity ≠ release permission; the checklist must come from approved policy rows with independent evidence; the portal must not issue a substitute sanction/NOC. | Release Authorization screenshot |
| A-07 | **Evidence model is the old L0–L3 ladder** ("L1 Only", "L2 Branch Verified", "L3 Gold Standard", an "Evidence levels" filter, an L0–L3 distribution on the dashboard). The spec forbids collapsing evidence into one score; attributes are separate (Declared · Extracted · Bank-confirmed · Ledger-reconciled · Inconclusive/Rejected). | Dashboard, Search, Bank Verification |
| A-08 | **Reports are fake.** "Generate Report File", "Generated exports & downloads history" and the KPI tiles (₹1,50,00,000 pool, ₹75,00,000 compliant) are static; no `/reports` or `/exports` API exists. | Reports screenshot; OpenAPI |
| A-09 | **AI Copilot includes "Text-to-SQL Analytics".** Unconstrained text-to-SQL is excluded by the spec (injection and data-leak risk). Policy Q&A must go through `/ai/policy-qa` with citation resolution. | AI Copilot tab |

### Medium
| ID | Finding |
|---|---|
| A-10 | **Backend gaps** (no routes at all): dashboard/KPIs, reports & exports (async jobs), audit viewer + chain verification, users/roles/assignments/recertification/invitations, MFA/passkeys/session list, global search + saved views, reminder schedule & scheduler status, maturity calendar, renewals/lineage UI endpoints beyond `instruments/lineage`, help/support/grievance, retention/legal-hold/rights, templates admin, institution-user management. |
| A-11 | `/docs` (Swagger) loads its JS/CSS from `cdn.jsdelivr.net`; docs must be disabled or self-hosted in production. `/openapi.json` 404 while `/v1/openapi.json` works — pick one documented path. |
| A-12 | Visual design is the retired dark neon theme; no empty/error/forbidden/offline states observed; header is crowded (11 tabs + 5 chips in two rows) and does not collapse for phones. |
| A-13 | Language switcher (EN / हिंदी / தமிழ்) is present; translation completeness not verified; spec requires reviewed vs machine-draft status per key. |

### Low
A-14 `favicon.ico` 404 on API origin. A-15 footer technology chips ("PostgreSQL 16", "Vite", etc.) are marketing, not information — remove. A-16 hard-coded sample institutions and FDR numbers (AXIS-FDR-99201, SBI-881920, HDFC-441029, PNB-771829) must be removed from every production path.

---

## 2. What exists (keep and harden)
The API surface is a good skeleton and mirrors the spec's modules: `auth` (login, logout, step-up), `me`, `me/permissions`; admin registry (feature/connector states + health checks); public receipt verification; institutions + onboarding (apply, review, batch-import); instruments (draft, submit, transition, versions, receipt, lineage); observations (create, send, respond, resolve) + case comments; intake/scrutiny/assign queues; documents (upload-intent, direct upload, download, extract, extraction review); bank verification requests (create, respond, decision, escalate); statement import, batches, lines, exceptions; discrepancy evaluate/generate-observation/acknowledge; policies (import-drafts, approve); release-requests (checklist rule, clearances, recommendation, decision, execution, discharge); notifications (list/read/ack/action, device register/revoke, preferences, test, DLQ + replay, funnel); SSE `/stream`; AI (`status`, `policy-qa`, `case-summary`, `translation-draft`); health/ready probes. Whether each handler enforces authorisation, scope, RLS, idempotency, optimistic concurrency and audit/outbox is **unverified** and is the first thing Phase R0 tests.

## 3. Coverage against the spec (modules F-01…F-28, mobile M-01…M-21)

Legend: **API** = route exists (behaviour unverified) · **MOCK** = UI only, hard-coded · **—** = nothing.

| Module | State | Gap to close |
|---|---|---|
| F-01 Identity, sessions, MFA, step-up, recertification | API (login/step-up) · UI — | Entire client auth; MFA/passkeys; sessions list; lockout; invitations; recovery; recertification |
| F-02 Institution registry & onboarding | API · UI MOCK | Real screens; merge-review queue; import wizard with dry run |
| F-03 Instrument register & versions | API · UI MOCK | Real list/detail/wizard, diff view, receipts |
| F-04 Document vault/upload pipeline | API · UI MOCK ("Demo FDR") | Real upload (resumable), scan status, hash, viewer |
| F-05 OCR/extraction review | API · UI — | Side-by-side review UI |
| F-06 Bank verification & evidence decision | API · UI MOCK | Workbench + isolated bank-verifier portal |
| F-07 Statement import & reconciliation | API · UI MOCK | Real import UI, matches, exceptions; remove "simulate" |
| F-08 Discrepancy engine | API · UI — | Rule list, outputs as draft observations |
| F-09 Observations/casework | API · UI — | Inbox/detail/threads (internal vs institution-visible) |
| F-10 Lifecycle & escalation scheduler | — / MOCK ladder | Scheduler, approved-schedule gate, reminders, heartbeat, admin alert |
| F-11 Renewal & lineage | API (lineage) · UI — | Lineage graph, gap/overlap |
| F-12 Release workflow | API · UI MOCK (auto-eligible) | Policy-built checklist, clearances, maker-checker, step-up, execution evidence |
| F-13 Policy registry | API · UI — | Diff/approve UI, effective dates, BLOCKED penalties |
| F-14 Notifications (inbox, FCM/APNs/Web Push, DLQ, funnel) | API · UI MOCK (connectors fake HEALTHY) | Real inbox, preferences, device status, honest provider state |
| F-15 Realtime SSE | API (`/stream`) · UI — | Client subscription with Last-Event-ID |
| F-16 Dashboard, reports, exports | — · MOCK | Whole module |
| F-17 Search & saved views | — · MOCK | Whole module |
| F-18 Audit & access logging, chain verification | — · MOCK | Viewer, verification job, checkpoints |
| F-19 Admin (users, roles, connectors, DLQ, templates, retention) | partial (registry, DLQ) | Users/roles/assignments, templates, retention |
| F-20 Receipts & verifiable QR | API (public verify) · UI — | Public page, signed PDF, QR |
| F-21 Help/support/grievance · F-22 Retention/rights | — · static text | Workflows |
| F-23 Migration/bulk import · F-24 Queues/workload · F-25 Comments | partial API · — | UI + supervisor board |
| F-26 Policy Q&A / case summary | API (`/ai/*`) · UI partial + disallowed text-to-SQL | Wire to API, citations, remove SQL |
| F-27 i18n · F-28 Accessibility | switcher only | Catalogue, review status, a11y pass |
| M-01…M-21 (push, biometric lock, scanner, QR, widgets, offline cache, quick actions…) | **Nothing runnable** | All |

## 4. What to do next (in this order)
1. **Make it boot and make it honest (R0–R1):** fix the Expo/Metro setup so web preview, Expo Go and a dev build all start; remove every simulation/demo/fake-health item (A-04, A-05, A-16); add the production-guard test.
2. **Real authentication and the 13 roles (R2):** login, MFA, step-up, sessions, invitations, navigation manifest from the server, staging users, role walkthrough tests (A-03).
3. **Wire both clients to the API with a generated client (R3)** and delete every hard-coded array.
4. **Fill the missing backend modules (R4):** dashboard, reports/exports, audit, users/roles, search, reminders/scheduler, sessions, help, retention.
5. **Apply the new design system on web and mobile (R5–R6)** from `design/preview.html` and `design/DESIGN_SPEC.md`.
6. **Realtime + push + mobile-native features (R7)**, then **hardening, a11y, performance, docs (R8)** and an **independent final audit (R9)**.

## 5. Features and functions to add (beyond the first build)
Role-aware home with live "Needs your action" and real counts · global search / ⌘K palette with saved views and shareable deep links · maturity calendar with a tokenised **.ics subscription feed** and "add to calendar" on mobile · bulk actions + keyboard shortcuts for officers · document viewer with side-by-side extraction review and region highlights · case timeline with provenance drawer on every fact · institution onboarding checklist with a **real** progress bar · per-role digest e-mail (opt-in, only when SMTP is configured) · notification preferences with quiet hours for optional categories only · dark mode, font scale, Hindi/Tamil with review status · institution compliance summary report · public receipt verification page + in-app QR scanner · import wizard (mapping versions, dry-run) · delegation and access-recertification admin UI · status banner for degraded integrations and maintenance windows · printable scoped case summary · mobile: document scanner, biometric lock, home-screen widgets (counts only), quick actions, offline read cache, device/notification status with a real test push.
